package com.watafa.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

/** Small key/value state store. Structured collections remain versioned JSON payloads. */
@Entity(tableName = "app_state")
data class AppStateEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface AppStateDao {
    @Query("SELECT * FROM app_state")
    suspend fun getAll(): List<AppStateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(values: List<AppStateEntity>)
}

@Database(entities = [AppStateEntity::class], version = 1, exportSchema = false)
abstract class WatafaDatabase : RoomDatabase() {
    abstract fun appStateDao(): AppStateDao

    companion object {
        @Volatile private var INSTANCE: WatafaDatabase? = null

        fun get(context: Context): WatafaDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                WatafaDatabase::class.java,
                "watafa.db"
            ).build().also { INSTANCE = it }
        }
    }
}
