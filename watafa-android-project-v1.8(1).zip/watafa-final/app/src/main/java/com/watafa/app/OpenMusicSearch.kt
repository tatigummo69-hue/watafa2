package com.watafa.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A result whose playback URL is published by an open catalogue. */
data class OnlineTrack(
    val id: String,
    val title: String,
    val artist: String,
    val streamUrl: String,
    val source: String,
    val license: String
)

/** Searches public catalogues and returns only records with an explicit open/public-domain licence. */
suspend fun searchOpenCatalogues(rawQuery: String): List<OnlineTrack> = withContext(Dispatchers.IO) {
    val query = rawQuery.trim()
    if (query.isBlank()) return@withContext emptyList()
    val sourceResults = coroutineScope {
        listOf(
            async(Dispatchers.IO) { runCatching { searchWikimedia(query) } },
            async(Dispatchers.IO) { runCatching { searchInternetArchive(query) } }
        ).awaitAll()
    }
    val successful = sourceResults.filter { it.isSuccess }
    if (successful.isEmpty()) throw sourceResults.first().exceptionOrNull() ?: IllegalStateException("Каталоги недоступны")
    successful.flatMap { it.getOrDefault(emptyList()) }.distinctBy { it.streamUrl }.take(40)
}

private fun requestJson(url: String): JSONObject {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 10000
        readTimeout = 15000
        setRequestProperty("User-Agent", "watafa-Android/1.7.0 (open-music-search)")
        setRequestProperty("Accept", "application/json")
    }
    return try {
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (status !in 200..299) {
            throw IllegalStateException("Музыкальный каталог вернул HTTP $status")
        }
        JSONObject(body)
    } finally {
        connection.disconnect()
    }
}

private fun searchWikimedia(query: String): List<OnlineTrack> {
    val encoded = URLEncoder.encode("filemime:audio $query", "UTF-8")
    val endpoint = "https://commons.wikimedia.org/w/api.php?action=query&generator=search" +
        "&gsrsearch=$encoded&gsrnamespace=6&gsrlimit=20&prop=imageinfo" +
        "&iiprop=url%7Cextmetadata&format=json"
    val root = requestJson(endpoint)
    val pages = root.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
    val output = mutableListOf<OnlineTrack>()
    val keys = pages.keys()
    while (keys.hasNext()) {
        val page = pages.optJSONObject(keys.next()) ?: continue
        val info = page.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
        val mediaUrl = info.optString("url")
        if (!mediaUrl.startsWith("https://") || !isAudioUrl(mediaUrl)) continue
        val metadata = info.optJSONObject("extmetadata") ?: JSONObject()
        val license = metadata.optJSONObject("LicenseShortName")?.optString("value").orEmpty()
        val licenseUrl = metadata.optJSONObject("LicenseUrl")?.optString("value").orEmpty()
        if (!isOpenLicense(license, licenseUrl)) continue
        val artist = metadata.optJSONObject("Artist")?.optString("value")
            ?.replace(Regex("<[^>]*>"), "")?.takeIf { it.isNotBlank() } ?: "Неизвестный исполнитель"
        output.add(OnlineTrack(
            id = "commons:${page.optLong("pageid")}",
            title = page.optString("title").substringAfterLast("File:").substringBeforeLast('.'),
            artist = artist,
            streamUrl = mediaUrl,
            source = "Wikimedia Commons",
            license = license.ifBlank { licenseUrl }
        ))
    }
    return output
}

private suspend fun searchInternetArchive(query: String): List<OnlineTrack> {
    val encoded = URLEncoder.encode("mediatype:audio AND ($query)", "UTF-8")
    val endpoint = "https://archive.org/advancedsearch.php?q=$encoded" +
        "&fl[]=identifier&fl[]=title&fl[]=creator&rows=12&page=1&output=json"
    val docs = requestJson(endpoint).optJSONObject("response")?.optJSONArray("docs") ?: return emptyList()
    val docList = (0 until docs.length()).mapNotNull { docs.optJSONObject(it) }.take(8)
    // Fetch item metadata concurrently to avoid serial network delays.
    val records = coroutineScope {
        docList.map { doc -> async(Dispatchers.IO) {
            val identifier = doc.optString("identifier")
            val metadata = if (identifier.isBlank()) null else runCatching {
                requestJson("https://archive.org/metadata/${URLEncoder.encode(identifier, "UTF-8")}")
            }.getOrNull()
            doc to metadata
        } }.awaitAll()
    }
    val output = mutableListOf<OnlineTrack>()
    for ((doc, metadata) in records) {
        val identifier = doc.optString("identifier")
        val itemMetadata = metadata ?: continue
        val meta = itemMetadata.optJSONObject("metadata") ?: JSONObject()
        val licenseUrl = meta.optString("licenseurl")
        val license = meta.optString("license")
        if (!isOpenLicense(license, licenseUrl)) continue
        val files = itemMetadata.optJSONArray("files") ?: continue
        for (j in 0 until files.length()) {
            val file = files.optJSONObject(j) ?: continue
            val name = file.optString("name")
            if (!isAudioUrl(name) || file.optString("source") == "original" && file.optString("private") == "true") continue
            val safeName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            val creator = meta.optString("creator").let { value ->
                when {
                    value.isBlank() -> "Неизвестный исполнитель"
                    value.startsWith("[") -> runCatching { org.json.JSONArray(value).optString(0) }.getOrDefault(value)
                    else -> value
                }
            }
            output.add(OnlineTrack(
                id = "archive:$identifier:$name",
                title = doc.optString("title").ifBlank { name.substringAfterLast('/') },
                artist = creator,
                streamUrl = "https://archive.org/download/$identifier/$safeName",
                source = "Internet Archive",
                license = license.ifBlank { licenseUrl }
            ))
            break
        }
    }
    return output
}

internal fun isAudioUrl(value: String): Boolean {
    val path = value.substringBefore('?').lowercase()
    return listOf(".mp3", ".ogg", ".oga", ".opus", ".flac", ".m4a", ".wav", ".aiff").any(path::endsWith)
}

internal fun isOpenLicense(name: String, url: String): Boolean {
    val text = "$name $url".lowercase()
    return text.contains("creativecommons.org/licenses/") ||
        text.contains("creativecommons zero") || text.contains("cc0") ||
        text.contains("public domain") || text.contains("publicdomain")
}
