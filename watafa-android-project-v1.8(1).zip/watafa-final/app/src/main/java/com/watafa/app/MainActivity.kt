package com.watafa.app

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private data class Track(
    val uri: Uri,
    val title: String,
    val artist: String,
    val source: String = "Локальный файл",
    val album: String = "Неизвестный альбом"
)

private data class Playlist(
    val id: String,
    val name: String,
    val trackUris: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 13, 13)
        window.navigationBarColor = android.graphics.Color.rgb(13, 13, 13)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        setContent {
            WatafaApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WatafaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val tracks = remember { mutableStateListOf<Track>() }
    val favorites = remember { mutableStateListOf<Uri>() }
    val disliked = remember { mutableStateListOf<Uri>() }
    val history = remember { mutableStateListOf<String>() }
    val playlists = remember { mutableStateListOf<Playlist>() }
    val database = remember(context) { WatafaDatabase.get(context) }
    val preferences = remember(context) {
        context.getSharedPreferences("watafa_library", android.content.Context.MODE_PRIVATE)
    }
    var libraryLoaded by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Главная") }

    // First launch after the Room upgrade: migrate the old SharedPreferences payloads once.
    LaunchedEffect(database) {
        val loadResult = runCatching {
            val dao = database.appStateDao()
            var stored = dao.getAll().associate { it.key to it.value }
            if (stored.isEmpty()) {
                val legacyKeys = listOf("tracks", "favorites", "disliked", "history", "playlists")
                val legacy = legacyKeys.associateWith { key ->
                    preferences.getString(key, if (key == "tracks" || key == "favorites" || key == "disliked" || key == "history" || key == "playlists") "[]" else "") ?: "[]"
                }
                dao.upsertAll(legacy.map { AppStateEntity(it.key, it.value) })
                stored = legacy
            }

            val savedTracks = JSONArray(stored["tracks"] ?: "[]")
            for (i in 0 until savedTracks.length()) {
                val item = savedTracks.optJSONObject(i) ?: continue
                val uriText = item.optString("uri")
                if (uriText.isBlank()) continue
                tracks.add(Track(Uri.parse(uriText), item.optString("title", "Неизвестный трек"),
                    item.optString("artist", "Локальный файл"), item.optString("source", "Локальный файл"), item.optString("album", "Неизвестный альбом")))
            }

            val savedFavorites = JSONArray(stored["favorites"] ?: "[]")
            for (i in 0 until savedFavorites.length()) {
                val uriText = savedFavorites.optString(i)
                if (uriText.isNotBlank()) favorites.add(Uri.parse(uriText))
            }
            val savedDisliked = JSONArray(stored["disliked"] ?: "[]")
            for (i in 0 until savedDisliked.length()) {
                val uriText = savedDisliked.optString(i)
                if (uriText.isNotBlank()) disliked.add(Uri.parse(uriText))
            }
            val savedHistory = JSONArray(stored["history"] ?: "[]")
            for (i in 0 until savedHistory.length()) {
                val uriText = savedHistory.optString(i)
                if (uriText.isNotBlank()) history.add(uriText)
            }
            val savedPlaylists = JSONArray(stored["playlists"] ?: "[]")
            for (i in 0 until savedPlaylists.length()) {
                val item = savedPlaylists.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name")
                if (id.isBlank() || name.isBlank()) continue
                val uriArray = item.optJSONArray("trackUris") ?: JSONArray()
                val uris = buildList {
                    for (j in 0 until uriArray.length()) {
                        val savedUri = uriArray.optString(j)
                        if (savedUri.isNotBlank()) add(savedUri)
                    }
                }
                playlists.add(Playlist(id, name, uris))
            }
        }
        libraryLoaded = loadResult.isSuccess
    }

    // Persist each collection in Room. The previous SharedPreferences data is retained as a backup.
    LaunchedEffect(tracks.toList(), favorites.toList(), disliked.toList(), history.toList(), playlists.toList(), libraryLoaded) {
        if (libraryLoaded) {
            val trackArray = JSONArray()
            tracks.forEach { track ->
                trackArray.put(JSONObject().put("uri", track.uri.toString()).put("title", track.title)
                    .put("artist", track.artist).put("source", track.source).put("album", track.album))
            }
            val favoritesArray = JSONArray().also { array -> favorites.forEach { array.put(it.toString()) } }
            val dislikedArray = JSONArray().also { array -> disliked.forEach { array.put(it.toString()) } }
            val historyArray = JSONArray().also { array -> history.forEach(array::put) }
            val playlistsArray = JSONArray()
            playlists.forEach { playlist ->
                val uriArray = JSONArray().also { array -> playlist.trackUris.forEach(array::put) }
                playlistsArray.put(JSONObject().put("id", playlist.id).put("name", playlist.name).put("trackUris", uriArray))
            }
            val values = listOf(
                AppStateEntity("tracks", trackArray.toString()),
                AppStateEntity("favorites", favoritesArray.toString()),
                AppStateEntity("disliked", dislikedArray.toString()),
                AppStateEntity("history", historyArray.toString()),
                AppStateEntity("playlists", playlistsArray.toString())
            )
            runCatching { database.appStateDao().upsertAll(values) }
        }
    }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var playbackQueue by remember { mutableStateOf<List<Track>>(emptyList()) }
    var isPlaying by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf("Добавлено недавно") }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var onlineMode by remember { mutableStateOf(false) }
    var onlineQuery by remember { mutableStateOf("") }
    var onlineResults by remember { mutableStateOf<List<OnlineTrack>>(emptyList()) }
    var onlineLoading by remember { mutableStateOf(false) }
    var onlineError by remember { mutableStateOf<String?>(null) }
    var showFavorites by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showRecommendations by remember { mutableStateOf(false) }
    var showArtists by remember { mutableStateOf(false) }
    var showAlbums by remember { mutableStateOf(false) }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    var selectedArtist by remember { mutableStateOf<String?>(null) }
    var showNowPlaying by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showPlaylists by remember { mutableStateOf(false) }
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var editingPlaylistId by remember { mutableStateOf<String?>(null) }
    var playlistDialog by remember { mutableStateOf<String?>(null) }
    var playlistName by remember { mutableStateOf("") }
    var showAddTracksDialog by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaController?>(null) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var sleepAtTrackEnd by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1f) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                player = future.get()
            } catch (_: Exception) { }
        }, { command -> command.run() })
        onDispose {
            MediaController.releaseFuture(future)
        }
    }

    DisposableEffect(player) {
        val activePlayer = player ?: return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentIndex = activePlayer.currentMediaItemIndex
                playbackQueue.getOrNull(currentIndex)?.let { track ->
                    history.remove(track.uri.toString())
                    history.add(0, track.uri.toString())
                    while (history.size > 100) history.removeAt(history.lastIndex)
                }
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = activePlayer.duration.coerceAtLeast(0L)
            }
        }
        activePlayer.addListener(listener)
        onDispose { activePlayer.removeListener(listener) }
    }

    LaunchedEffect(player) {
        while (true) {
            player?.let {
                position = it.currentPosition.coerceAtLeast(0L)
                duration = it.duration.coerceAtLeast(0L)
                isPlaying = it.isPlaying
                shuffleEnabled = it.shuffleModeEnabled
                repeatMode = it.repeatMode
                if (it.currentMediaItemIndex >= 0) currentIndex = it.currentMediaItemIndex
            }
            delay(500)
        }
    }

    LaunchedEffect(sleepMinutes) {
        if (sleepMinutes > 0) {
            delay(sleepMinutes * 60_000L)
            player?.pause()
            sleepMinutes = 0
            sleepAtTrackEnd = false
        }
    }

    LaunchedEffect(position, duration, sleepAtTrackEnd) {
        if (sleepAtTrackEnd && duration > 0L && position >= duration - 700L) {
            player?.pause()
            sleepAtTrackEnd = false
        }
    }

    suspend fun readAudioMetadata(uri: Uri): Triple<String?, String?, String?> =
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                Triple(
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                )
            } catch (_: Exception) {
                Triple(null, null, null)
            } finally {
                runCatching { retriever.release() }
            }
        }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) { }
                if (tracks.any { it.uri == uri }) return@forEach
                val fallbackName = uri.lastPathSegment?.substringAfterLast('/')
                    ?.substringBeforeLast('.')?.replace('_', ' ') ?: "Неизвестный трек"
                val metadata = readAudioMetadata(uri)
                val title = metadata.first?.takeIf { it.isNotBlank() } ?: fallbackName
                val artist = metadata.second?.takeIf { it.isNotBlank() } ?: "Локальный файл"
                val album = metadata.third?.takeIf { it.isNotBlank() } ?: "Неизвестный альбом"
                if (tracks.none { it.uri == uri }) tracks.add(Track(uri, title, artist, album = album))
            }
        }
    }

    fun playQueue(queue: List<Track>, index: Int) {
        val controller = player ?: return
        if (queue.isEmpty() || index !in queue.indices) return
        playbackQueue = queue.toList()
        currentIndex = index
        queue.getOrNull(index)?.let { track ->
            history.remove(track.uri.toString())
            history.add(0, track.uri.toString())
            while (history.size > 100) history.removeAt(history.lastIndex)
        }
        controller.setMediaItems(queue.map { track ->
            MediaItem.Builder()
                .setMediaId(track.uri.toString())
                .setUri(track.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .setDisplayTitle(track.title)
                        .build()
                )
                .build()
        }, index, 0L)
        controller.prepare()
        controller.play()
        showNowPlaying = true
    }

    fun playAt(index: Int) = playQueue(tracks, index)

    val activeTrack = playbackQueue.getOrNull(currentIndex)

    val favoriteArtists = tracks.filter { favorites.contains(it.uri) }
        .map { it.artist.lowercase() }.filter { it.isNotBlank() && it != "локальный файл" }.toSet()
    val orderedTracks = when {
        showHistory -> history.mapNotNull { uri ->
            val index = tracks.indexOfFirst { it.uri.toString() == uri }
            if (index >= 0) index to tracks[index] else null
        }
        showRecommendations -> tracks.indices.map { it to tracks[it] }
            .filter { (_, track) -> !disliked.contains(track.uri) }
            .sortedByDescending { (_, track) ->
                (if (favorites.contains(track.uri)) 2 else 0) +
                    (if (track.artist.lowercase() in favoriteArtists) 3 else 0) +
                    (if (history.contains(track.uri.toString())) 1 else 0)
            }
        else -> tracks.indices.map { it to tracks[it] }
    }
    val filteredTracks = orderedTracks.filter { (_, track) ->
        (!showFavorites || favorites.contains(track.uri)) &&
            (search.isBlank() || track.title.contains(search, ignoreCase = true) ||
                track.artist.contains(search, ignoreCase = true) || track.album.contains(search, ignoreCase = true))
    }
    val visibleTracks = when (sortMode) {
        "Название А–Я" -> filteredTracks.sortedBy { it.second.title.lowercase() }
        "Исполнитель А–Я" -> filteredTracks.sortedBy { it.second.artist.lowercase() }
        "Альбом А–Я" -> filteredTracks.sortedBy { it.second.album.lowercase() }
        else -> filteredTracks
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFF1F1F1),
            background = Color(0xFF0D0D0D),
            surface = Color(0xFF1A1A1A),
            onBackground = Color(0xFFF4F5F7),
            onSurface = Color(0xFFF4F5F7)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF0D0D0D),
            bottomBar = {
                Column {
                    if (activeTrack != null && !showNowPlaying) {
                        MiniPlayer(
                            track = activeTrack,
                            playing = isPlaying,
                            onOpen = { showNowPlaying = true },
                            onPlayPause = { player?.let { if (it.isPlaying) it.pause() else it.play() } },
                            onNext = { player?.seekToNextMediaItem() }
                        )
                    }
                    if (!showNowPlaying && !showQueue && !showPlaylists) {
                        NavigationBar(containerColor = Color(0xFF111111), contentColor = Color.White) {
                            listOf("Главная", "Поиск", "Медиатека", "Профиль").forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = {
                                        selectedTab = tab
                                        if (tab == "Поиск") { showFavorites = false; showHistory = false; showRecommendations = false; onlineMode = true }
                                        if (tab == "Медиатека") { onlineMode = false }
                                    },
                                    icon = {
                                        Text(when (tab) { "Главная" -> "⌂"; "Поиск" -> "⌕"; "Медиатека" -> "♫"; else -> "○" }, fontSize = 21.sp)
                                    },
                                    label = { Text(tab, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = Color.White,
                                        indicatorColor = Color(0xFF303030),
                                        unselectedIconColor = Color(0xFF888888),
                                        unselectedTextColor = Color(0xFF888888)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            if (showQueue && activeTrack != null) {
                QueueScreen(
                    queue = playbackQueue,
                    currentIndex = currentIndex,
                    onBack = { showQueue = false },
                    onSelect = { index ->
                        player?.seekTo(index, 0L)
                        player?.play()
                        showQueue = false
                        showNowPlaying = true
                    },
                    modifier = Modifier.padding(padding)
                )
            } else if (showNowPlaying && activeTrack != null) {
                NowPlayingScreen(
                    track = activeTrack,
                    playing = isPlaying,
                    position = position,
                    duration = duration,
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    sleepMinutes = sleepMinutes,
                    sleepAtTrackEnd = sleepAtTrackEnd,
                    playbackSpeed = playbackSpeed,
                    onOpenSleepTimer = { showSleepDialog = true },
                    onOpenSpeed = { showSpeedDialog = true },
                    onBack = { showNowPlaying = false },
                    onPlayPause = { player?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onPrevious = { player?.seekToPreviousMediaItem() },
                    onNext = { player?.seekToNextMediaItem() },
                    onSeek = { player?.seekTo(it) },
                    onShuffle = { player?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled; shuffleEnabled = it.shuffleModeEnabled } },
                    onRepeat = { player?.let {
                        val next = when (it.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        it.repeatMode = next
                        repeatMode = next
                    } },
                    onQueue = { showQueue = true },
                    modifier = Modifier.padding(padding)
                )
            } else if (showPlaylists) {
                val selectedPlaylist = playlists.firstOrNull { it.id == selectedPlaylistId }
                if (selectedPlaylistId != null && selectedPlaylist != null) {
                    PlaylistDetailScreen(
                        playlist = selectedPlaylist,
                        tracks = tracks,
                        onBack = { selectedPlaylistId = null },
                        onAddTracks = { showAddTracksDialog = true },
                        onRemoveTrack = { uri ->
                            val index = playlists.indexOfFirst { it.id == selectedPlaylist.id }
                            if (index >= 0) playlists[index] = selectedPlaylist.copy(
                                trackUris = selectedPlaylist.trackUris.filterNot { it == uri.toString() }
                            )
                        },
                        onPlay = { index -> playQueue(
                            selectedPlaylist.trackUris.mapNotNull { uri ->
                                tracks.firstOrNull { it.uri.toString() == uri }
                            }, index
                        ) },
                        modifier = Modifier.padding(padding)
                    )
                } else {
                    PlaylistListScreen(
                        playlists = playlists,
                        tracks = tracks,
                        onBack = { showPlaylists = false },
                        onCreate = { playlistName = ""; editingPlaylistId = null; playlistDialog = "create" },
                        onOpen = { selectedPlaylistId = it.id },
                        onRename = { playlistName = it.name; editingPlaylistId = it.id; playlistDialog = "rename" },
                        onDelete = { playlist -> playlists.removeAll { it.id == playlist.id } },
                        modifier = Modifier.padding(padding)
                    )
                }
            } else if (selectedTab == "Главная") {
                HomeScreen(
                    trackCount = tracks.size,
                    favoriteCount = favorites.size,
                    playlistCount = playlists.size,
                    recentTrack = activeTrack,
                    onAddMusic = { picker.launch(arrayOf("audio/*")) },
                    onOpenLibrary = { selectedTab = "Медиатека" },
                    onOpenSearch = { selectedTab = "Поиск" },
                    onOpenFavorites = { selectedTab = "Медиатека"; showFavorites = true; showHistory = false; showRecommendations = false },
                    onOpenPlaylists = { showPlaylists = true }
                , modifier = Modifier.padding(padding))
            } else if (selectedTab == "Профиль") {
                ProfileScreen(
                    trackCount = tracks.size,
                    favoriteCount = favorites.size,
                    playlistCount = playlists.size,
                    onOpenPlaylists = { showPlaylists = true },
                    onOpenFavorites = { selectedTab = "Медиатека"; showFavorites = true; showHistory = false; showRecommendations = false },
                    onOpenHistory = { selectedTab = "Медиатека"; showHistory = true; showFavorites = false; showRecommendations = false },
                    modifier = Modifier.padding(padding)
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)
                ) {
                    Spacer(Modifier.height(22.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("watafa", fontSize = 32.sp, fontWeight = FontWeight.Black,
                                color = Color(0xFFF1F1F1))
                            Text("Твоя музыка. Твои правила.", color = Color.LightGray, fontSize = 13.sp)
                        }
                        Surface(shape = CircleShape, color = Color(0xFF252525),
                            modifier = Modifier.size(48.dp).clickable { picker.launch(arrayOf("audio/*")) }) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Add, contentDescription = "Добавить музыку",
                                    tint = Color(0xFFF1F1F1))
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text(if (onlineMode) "Открой новую музыку" else "Слушай своё", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(if (onlineMode) "Поиск по открытым музыкальным каталогам" else "Добавь MP3-файлы со своего устройства",
                        color = Color(0xFFA5A5A5), fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = !onlineMode, onClick = { onlineMode = false }, label = { Text("Моя музыка") })
                        FilterChip(selected = onlineMode, onClick = { onlineMode = true }, label = { Text("Онлайн-каталоги") })
                    }
                    if (onlineMode) {
                        OutlinedTextField(
                            value = onlineQuery, onValueChange = { onlineQuery = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("Название песни или исполнитель") },
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFFF1F1F1), unfocusedBorderColor = Color(0xFF414141))
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            onlineLoading = true; onlineError = null
                            scope.launch {
                                val result = runCatching { searchOpenCatalogues(onlineQuery) }
                                onlineResults = result.getOrDefault(emptyList())
                                onlineError = result.exceptionOrNull()?.localizedMessage
                                onlineLoading = false
                            }
                        }, enabled = onlineQuery.isNotBlank() && !onlineLoading, modifier = Modifier.fillMaxWidth()) {
                            Text(if (onlineLoading) "Ищем…" else "Найти музыку")
                        }
                        when {
                            onlineLoading -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                            onlineError != null -> Text("Не удалось выполнить поиск. Проверь подключение к интернету и попробуй ещё раз.", color = Color(0xFFBDBDBD), modifier = Modifier.padding(12.dp))
                            onlineResults.isEmpty() -> Text("Ищи музыку из Wikimedia Commons и Internet Archive. Показываются только записи с распознанной открытой лицензией.", color = Color(0xFFA5A5A5), fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp))
                            else -> LazyColumn(contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(onlineResults, key = { _, item -> item.id }) { _, item ->
                                    OnlineTrackRow(item = item, onPlay = {
                                        val track = Track(Uri.parse(item.streamUrl), item.title, item.artist, item.source, "Неизвестный альбом")
                                        val existing = tracks.indexOfFirst { it.uri == track.uri }
                                        if (existing >= 0) playQueue(tracks.toList(), existing)
                                        else { tracks.add(track); playQueue(tracks.toList(), tracks.lastIndex) }
                                    }, onFavorite = {
                                        val uri = Uri.parse(item.streamUrl)
                                        if (tracks.none { it.uri == uri }) tracks.add(Track(uri, item.title, item.artist, item.source, "Неизвестный альбом"))
                                        if (!favorites.contains(uri)) favorites.add(uri) else favorites.remove(uri)
                                    }, favorite = favorites.contains(Uri.parse(item.streamUrl)))
                                }
                            }
                        }
                    } else {
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Поиск по библиотеке") },
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFF1F1F1),
                            unfocusedBorderColor = Color(0xFF414141)
                        )
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(selected = !showFavorites && !showHistory && !showRecommendations && !showArtists,
                            onClick = { showFavorites = false; showHistory = false; showRecommendations = false; showArtists = false; showAlbums = false; selectedArtist = null; selectedAlbum = null },
                            label = { Text("Все") })
                        FilterChip(selected = showFavorites, onClick = {
                            showFavorites = true; showHistory = false; showRecommendations = false; showArtists = false; showAlbums = false; selectedArtist = null; selectedAlbum = null
                        }, label = { Text("Избранное") })
                        FilterChip(selected = showRecommendations, onClick = {
                            showFavorites = false; showHistory = false; showRecommendations = true; showArtists = false; showAlbums = false; selectedArtist = null; selectedAlbum = null
                        }, label = { Text("Для тебя") })
                        FilterChip(selected = showHistory, onClick = {
                            showFavorites = false; showHistory = true; showRecommendations = false; showArtists = false; showAlbums = false; selectedArtist = null; selectedAlbum = null
                        }, label = { Text("История") })
                        FilterChip(selected = showArtists, onClick = {
                            showFavorites = false; showHistory = false; showRecommendations = false; showArtists = true; showAlbums = false; selectedArtist = null; selectedAlbum = null
                        }, label = { Text("Исполнители") })
                        FilterChip(selected = showAlbums, onClick = {
                            showFavorites = false; showHistory = false; showRecommendations = false
                            showArtists = false; showAlbums = true; selectedAlbum = null
                        }, label = { Text("Альбомы") })
                        FilterChip(selected = false, onClick = { showPlaylists = true },
                            label = { Text("Плейлисты") })
                    }
                    Spacer(Modifier.height(10.dp))
                    if (!showAlbums && !showArtists && !showHistory && !showRecommendations) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Box {
                                TextButton(onClick = { sortMenuExpanded = true }) {
                                    Text("Сортировка: $sortMode", color = Color(0xFFCCCCCC), fontSize = 12.sp)
                                }
                                DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false },
                                    containerColor = Color(0xFF252525)) {
                                    listOf("Добавлено недавно", "Название А–Я", "Исполнитель А–Я", "Альбом А–Я").forEach { option ->
                                        DropdownMenuItem(text = { Text(option, color = Color.White) }, onClick = {
                                            sortMode = option
                                            sortMenuExpanded = false
                                        })
                                    }
                                }
                            }
                        }
                    }
                    if (showAlbums && selectedAlbum != null) {
                        val albumTracks = tracks.filter { it.album.equals(selectedAlbum, ignoreCase = true) }
                        Column(Modifier.fillMaxSize()) {
                            TextButton(onClick = { selectedAlbum = null }) { Text("‹  Все альбомы", color = Color.White) }
                            Text(selectedAlbum ?: "Альбом", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("${albumTracks.firstOrNull()?.artist ?: "Разные исполнители"} · ${albumTracks.size} треков", color = Color(0xFF999999), fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                itemsIndexed(albumTracks, key = { _, track -> track.uri.toString() }) { index, track ->
                                    TrackRow(track = track, selected = activeTrack?.uri == track.uri,
                                        favorite = favorites.contains(track.uri), onClick = { playQueue(albumTracks, index) },
                                        onFavorite = { if (favorites.contains(track.uri)) favorites.remove(track.uri) else favorites.add(track.uri) },
                                        onDislike = { if (!disliked.contains(track.uri)) disliked.add(track.uri) })
                                }
                            }
                        }
                    } else if (showAlbums) {
                        val albumGroups = tracks.filter { it.album.isNotBlank() && it.album != "Неизвестный альбом" }
                            .groupBy { it.album.trim() }.toList().sortedBy { it.first.lowercase() }
                        if (albumGroups.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Альбомы появятся, когда добавишь файлы с заполненными аудиотегами", color = Color(0xFF999999), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                itemsIndexed(albumGroups, key = { _, group -> group.first }) { _, group ->
                                    Surface(color = Color(0xFF1B1B1B), shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth().clickable { selectedAlbum = group.first }) {
                                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                            TrackArtwork(uri = group.second.first().uri, modifier = Modifier.size(52.dp), rounded = 12.dp)
                                            Spacer(Modifier.width(14.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(group.first, fontWeight = FontWeight.SemiBold)
                                                Text("${group.second.firstOrNull()?.artist ?: "Разные исполнители"} · ${group.second.size} треков", color = Color(0xFF999999), fontSize = 12.sp)
                                            }
                                            Text("›", color = Color(0xFF999999), fontSize = 24.sp)
                                        }
                                    }
                                }
                            }
                        }
                    } else if (showArtists && selectedArtist != null) {
                        val artistTracks = tracks.filter { it.artist.equals(selectedArtist, ignoreCase = true) }
                        Column(Modifier.fillMaxSize()) {
                            TextButton(onClick = { selectedArtist = null }) { Text("‹  Все исполнители", color = Color.White) }
                            Text(selectedArtist ?: "Исполнитель", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("${artistTracks.size} треков в твоей медиатеке", color = Color(0xFF999999), fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                itemsIndexed(artistTracks, key = { _, track -> track.uri.toString() }) { index, track ->
                                    TrackRow(track = track, selected = activeTrack?.uri == track.uri,
                                        favorite = favorites.contains(track.uri), onClick = { playQueue(artistTracks, index) },
                                        onFavorite = { if (favorites.contains(track.uri)) favorites.remove(track.uri) else favorites.add(track.uri) },
                                        onDislike = { if (!disliked.contains(track.uri)) disliked.add(track.uri) })
                                }
                            }
                        }
                    } else if (showArtists) {
                        val artistGroups = tracks.filter { it.artist.isNotBlank() && it.artist != "Локальный файл" }
                            .groupBy { it.artist.trim() }.toList().sortedBy { it.first.lowercase() }
                        if (artistGroups.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Исполнители появятся после добавления музыки с заполненными тегами", color = Color(0xFF999999), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                                itemsIndexed(artistGroups, key = { _, group -> group.first }) { _, group ->
                                    Surface(color = Color(0xFF1B1B1B), shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.fillMaxWidth().clickable { selectedArtist = group.first }) {
                                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Surface(color = Color(0xFF303030), shape = CircleShape, modifier = Modifier.size(48.dp)) {
                                                Box(contentAlignment = Alignment.Center) { Text(group.first.take(1).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                                            }
                                            Spacer(Modifier.width(14.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(group.first, fontWeight = FontWeight.SemiBold)
                                                Text("${group.second.size} треков", color = Color(0xFF999999), fontSize = 12.sp)
                                            }
                                            Text("›", color = Color(0xFF999999), fontSize = 24.sp)
                                        }
                                    }
                                }
                            }
                        }
                    } else if (tracks.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("♫", fontSize = 64.sp, color = Color(0xFFF1F1F1))
                                Text("Здесь пока тихо", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Нажми + и добавь свои аудиофайлы",
                                    color = Color(0xFFA5A5A5), fontSize = 13.sp)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Добавить музыку")
                                }
                            }
                        }
                    } else if (visibleTracks.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                when {
                                    showHistory -> "История прослушивания пока пуста"
                                    showRecommendations -> "Пока мало данных для рекомендаций. Добавь треки и отмечай любимые"
                                    else -> "Ничего не найдено"
                                },
                                color = Color(0xFFA5A5A5), textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(contentPadding = PaddingValues(bottom = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(visibleTracks, key = { _, item -> item.second.uri.toString() }) { _, indexed ->
                                TrackRow(
                                    track = indexed.second,
                                    selected = activeTrack?.uri == indexed.second.uri,
                                    favorite = favorites.contains(indexed.second.uri),
                                    onClick = { playQueue(visibleTracks.map { it.second }, visibleTracks.indexOf(indexed)) },
                                    onFavorite = {
                                        if (favorites.contains(indexed.second.uri)) favorites.remove(indexed.second.uri)
                                        else favorites.add(indexed.second.uri)
                                    },
                                    onDislike = { if (!disliked.contains(indexed.second.uri)) disliked.add(indexed.second.uri); showRecommendations = true; showFavorites = false; showHistory = false }
                                )
                            }
                        }
                    }
                    }
                }
            }
        }

        if (playlistDialog != null) {
            AlertDialog(
                onDismissRequest = { playlistDialog = null },
                title = { Text(if (playlistDialog == "create") "Новый плейлист" else "Переименовать плейлист") },
                text = {
                    OutlinedTextField(
                        value = playlistName,
                        onValueChange = { playlistName = it },
                        singleLine = true,
                        label = { Text("Название") }
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val cleanName = playlistName.trim()
                        if (cleanName.isNotEmpty()) {
                            if (playlistDialog == "create") {
                                val id = java.util.UUID.randomUUID().toString()
                                playlists.add(Playlist(id, cleanName, emptyList()))
                            } else {
                                val index = playlists.indexOfFirst { it.id == editingPlaylistId }
                                if (index >= 0) playlists[index] = playlists[index].copy(name = cleanName)
                            }
                            playlistDialog = null
                        }
                    }, enabled = playlistName.isNotBlank()) { Text("Сохранить") }
                },
                dismissButton = { TextButton(onClick = { playlistDialog = null }) { Text("Отмена") } }
            )
        }

        if (showAddTracksDialog && selectedPlaylistId != null) {
            val playlist = playlists.firstOrNull { it.id == selectedPlaylistId }
            if (playlist != null) {
                AddTracksDialog(
                    tracks = tracks,
                    alreadyAdded = playlist.trackUris.toSet(),
                    onDismiss = { showAddTracksDialog = false },
                    onAdd = { selectedUris ->
                        val index = playlists.indexOfFirst { it.id == playlist.id }
                        if (index >= 0) playlists[index] = playlist.copy(
                            trackUris = (playlist.trackUris + selectedUris.map { it.toString() }).distinct()
                        )
                        showAddTracksDialog = false
                    }
                )
            }
        }

        if (showSleepDialog) {
            AlertDialog(
                onDismissRequest = { showSleepDialog = false },
                title = { Text("Таймер сна") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Остановить воспроизведение:")
                        listOf(15, 30, 45, 60, 90, 120).forEach { minutes ->
                            TextButton(onClick = {
                                sleepMinutes = minutes
                                sleepAtTrackEnd = false
                                showSleepDialog = false
                            }, modifier = Modifier.fillMaxWidth()) { Text("$minutes минут") }
                        }
                        TextButton(onClick = {
                            sleepMinutes = 0
                            sleepAtTrackEnd = true
                            showSleepDialog = false
                        }, modifier = Modifier.fillMaxWidth()) { Text("До конца текущего трека") }
                        if (sleepMinutes > 0 || sleepAtTrackEnd) {
                            TextButton(onClick = {
                                sleepMinutes = 0
                                sleepAtTrackEnd = false
                                showSleepDialog = false
                            }, modifier = Modifier.fillMaxWidth()) { Text("Отключить таймер") }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSleepDialog = false }) { Text("Закрыть") } }
            )
        }

        if (showSpeedDialog) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("Скорость воспроизведения") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f).forEach { speed ->
                            TextButton(onClick = {
                                player?.let { controller ->
                                    if (controller.isCommandAvailable(Player.COMMAND_SET_SPEED_AND_PITCH)) {
                                        controller.setPlaybackSpeed(speed)
                                        playbackSpeed = speed
                                    }
                                }
                                showSpeedDialog = false
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text((if (speed == 1f) "1× · Обычная" else "${speed}×") + if (playbackSpeed == speed) "  ✓" else "")
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSpeedDialog = false }) { Text("Закрыть") } }
            )
        }
    }
}

@Composable
private fun PlaylistListScreen(
    playlists: List<Playlist>, tracks: List<Track>,
    onBack: () -> Unit, onCreate: () -> Unit, onOpen: (Playlist) -> Unit,
    onRename: (Playlist) -> Unit, onDelete: (Playlist) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "К библиотеке") }
            Text("Плейлисты", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Text("Собирай музыку по настроению", color = Color(0xFFA5A5A5), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Создать плейлист")
        }
        Spacer(Modifier.height(12.dp))
        if (playlists.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Плейлистов пока нет", color = Color(0xFFA5A5A5))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(playlists, key = { _, item -> item.id }) { _, playlist ->
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF1A1A1A), RoundedCornerShape(16.dp))
                            .clickable { onOpen(playlist) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(52.dp).background(Color(0xFF303030), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Text("♫", color = Color(0xFFF1F1F1), fontSize = 27.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(playlist.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val count = playlist.trackUris.count { uri -> tracks.any { it.uri.toString() == uri } }
                            Text("$count треков", color = Color(0xFFA5A5A5), fontSize = 12.sp)
                        }
                        TextButton(onClick = { onRename(playlist) }) { Text("Изм.") }
                        TextButton(onClick = { onDelete(playlist) }) { Text("Удал.", color = Color(0xFFBDBDBD)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistDetailScreen(
    playlist: Playlist, tracks: List<Track>, onBack: () -> Unit,
    onAddTracks: () -> Unit, onRemoveTrack: (Uri) -> Unit,
    onPlay: (Int) -> Unit, modifier: Modifier = Modifier
) {
    val playlistTracks = playlist.trackUris.mapNotNull { uri -> tracks.firstOrNull { it.uri.toString() == uri } }
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад") }
            Text(playlist.name, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("${playlistTracks.size} треков", color = Color(0xFFA5A5A5), fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { onPlay(0) }, enabled = playlistTracks.isNotEmpty(), modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Слушать всё")
            }
            OutlinedButton(onClick = onAddTracks, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить")
            }
        }
        Spacer(Modifier.height(12.dp))
        if (playlistTracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Добавь сюда треки из своей библиотеки", color = Color(0xFFA5A5A5))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(playlistTracks, key = { _, track -> track.uri.toString() }) { _, track ->
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF1A1A1A), RoundedCornerShape(14.dp)).padding(start = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f).clickable { onPlay(playlistTracks.indexOf(track)) }.padding(vertical = 12.dp)) {
                            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(track.artist, color = Color(0xFFA5A5A5), fontSize = 12.sp)
                        }
                        TextButton(onClick = { onRemoveTrack(track.uri) }) { Text("Убрать") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddTracksDialog(
    tracks: List<Track>, alreadyAdded: Set<String>,
    onDismiss: () -> Unit, onAdd: (List<Uri>) -> Unit
) {
    val selected = remember { mutableStateListOf<Uri>() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить в плейлист") },
        text = {
            if (tracks.isEmpty()) Text("Сначала добавь музыку в библиотеку")
            else LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                itemsIndexed(tracks, key = { _, track -> track.uri.toString() }) { _, track ->
                    val isAlreadyAdded = track.uri.toString() in alreadyAdded
                    Row(Modifier.fillMaxWidth().clickable(enabled = !isAlreadyAdded) {
                        if (selected.contains(track.uri)) selected.remove(track.uri) else selected.add(track.uri)
                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isAlreadyAdded || selected.contains(track.uri), onCheckedChange = {
                            if (!isAlreadyAdded) {
                                if (it) selected.add(track.uri) else selected.remove(track.uri)
                            }
                        }, enabled = !isAlreadyAdded)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (isAlreadyAdded) Text("Уже в плейлисте", color = Color(0xFFA5A5A5), fontSize = 11.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(selected.toList()) }, enabled = selected.isNotEmpty()) { Text("Добавить (${selected.size})") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun OnlineTrackRow(item: OnlineTrack, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF1A1A1A), RoundedCornerShape(14.dp)).clickable(onClick = onPlay).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).background(Color(0xFF303030), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            Text("♫", color = Color(0xFFF1F1F1), fontSize = 24.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.artist, color = Color(0xFFA5A5A5), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${item.source} · ${item.license}", color = Color(0xFFF1F1F1), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "В избранное", tint = if (favorite) Color(0xFFF1F1F1) else Color.LightGray)
        }
        IconButton(onClick = onPlay) { Icon(Icons.Default.PlayArrow, contentDescription = "Слушать", tint = Color(0xFFF1F1F1)) }
    }
}

@Composable
private fun HomeScreen(
    trackCount: Int, favoriteCount: Int, playlistCount: Int, recentTrack: Track?,
    onAddMusic: () -> Unit, onOpenLibrary: () -> Unit, onOpenSearch: () -> Unit,
    onOpenFavorites: () -> Unit, onOpenPlaylists: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(horizontal = 22.dp)) {
        Spacer(Modifier.height(28.dp))
        Text("watafa", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Text("Твоя музыка. Твои правила.", color = Color(0xFF999999), fontSize = 13.sp)
        Spacer(Modifier.height(30.dp))
        Text("Добро пожаловать", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Музыка в спокойном, чистом интерфейсе", color = Color(0xFF9A9A9A), fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Surface(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenLibrary),
            color = Color(0xFF202020), shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("ТВОЯ МЕДИАТЕКА", color = Color(0xFFAAAAAA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("$trackCount треков", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Избранное · история · плейлисты", color = Color(0xFFAAAAAA), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeActionCard("Избранное", "$favoriteCount треков", "♥", onOpenFavorites, Modifier.weight(1f))
            HomeActionCard("Плейлисты", "$playlistCount создано", "♫", onOpenPlaylists, Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("Продолжить", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (recentTrack != null) {
            Surface(color = Color(0xFF1B1B1B), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenLibrary)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("♫", fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(recentTrack.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(recentTrack.artist, color = Color(0xFF999999), fontSize = 12.sp)
                    }
                    Text("Открыть", color = Color.White, fontSize = 12.sp)
                }
            }
        } else {
            Text("Здесь появится последний прослушанный трек", color = Color(0xFF888888), fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = onOpenSearch, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("Найти музыку")
        }
        OutlinedButton(onClick = onAddMusic, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("Добавить музыку с устройства")
        }
    }
}

@Composable
private fun HomeActionCard(title: String, subtitle: String, symbol: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier.clickable(onClick = onClick), color = Color(0xFF1B1B1B), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(symbol, fontSize = 24.sp)
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF999999), fontSize = 11.sp)
        }
    }
}

@Composable
private fun ProfileScreen(
    trackCount: Int, favoriteCount: Int, playlistCount: Int,
    onOpenPlaylists: () -> Unit, onOpenFavorites: () -> Unit, onOpenHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(horizontal = 22.dp)) {
        Spacer(Modifier.height(28.dp))
        Text("Профиль", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Личное пространство watafa", color = Color(0xFF999999), fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        Surface(color = Color(0xFF202020), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("w", fontSize = 38.sp, fontWeight = FontWeight.Black)
                Text("Моя коллекция", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("$trackCount треков · $favoriteCount избранных · $playlistCount плейлистов", color = Color(0xFFAAAAAA), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        ProfileRow("Избранное", "$favoriteCount треков", onOpenFavorites)
        ProfileRow("История прослушивания", "Недавно включённые треки", onOpenHistory)
        ProfileRow("Мои плейлисты", "$playlistCount плейлистов", onOpenPlaylists)
        Spacer(Modifier.height(22.dp))
        Text("О приложении", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("watafa — бесплатный музыкальный плеер с локальной библиотекой и поиском по открытым музыкальным каталогам.", color = Color(0xFF999999), fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text("Версия 1.3.0", color = Color(0xFF777777), fontSize = 11.sp)
    }
}

@Composable
private fun ProfileRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF999999), fontSize = 12.sp)
        }
        Text("›", fontSize = 25.sp, color = Color(0xFF999999))
    }
    HorizontalDivider(color = Color(0xFF292929))
}

@Composable
private fun TrackArtwork(
    uri: Uri,
    modifier: Modifier = Modifier,
    rounded: androidx.compose.ui.unit.Dp = 12.dp,
    placeholderSize: Int = 24
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    retriever.embeddedPicture?.let { bytes -> BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
                } finally {
                    retriever.release()
                }
            }.getOrNull()
        }
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(rounded),
        color = Color(0xFF303030)
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Обложка альбома",
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(
                listOf(Color(0xFF555555), Color(0xFF202020)))), contentAlignment = Alignment.Center) {
                Text("♫", color = Color(0xFFDDDDDD), fontSize = placeholderSize.sp)
            }
        }
    }
}

@Composable
private fun TrackRow(
    track: Track, selected: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit, onDislike: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(if (selected) Color(0xFF303030) else Color(0xFF1A1A1A), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TrackArtwork(uri = track.uri, modifier = Modifier.size(46.dp), rounded = 10.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = Color(0xFFA5A5A5), fontSize = 12.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "В избранное",
                tint = if (favorite) Color(0xFFF1F1F1) else Color.LightGray)
        }
        IconButton(onClick = onDislike) {
            Icon(Icons.Default.ThumbDown, contentDescription = "Не рекомендовать",
                tint = Color(0xFFA5A5A5))
        }
    }
}

@Composable
private fun MiniPlayer(
    track: Track, playing: Boolean, onOpen: () -> Unit,
    onPlayPause: () -> Unit, onNext: () -> Unit
) {
    Surface(color = Color(0xFF202020), tonalElevation = 8.dp) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            TrackArtwork(uri = track.uri, modifier = Modifier.size(40.dp), rounded = 8.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(track.artist, color = Color.LightGray, fontSize = 11.sp)
            }
            IconButton(onClick = onPlayPause) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Воспроизведение", tint = Color(0xFFF1F1F1))
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.SkipNext, contentDescription = "Следующий трек")
            }
        }
    }
}

@Composable
private fun NowPlayingScreen(
    track: Track, playing: Boolean, position: Long, duration: Long,
    shuffleEnabled: Boolean, repeatMode: Int,
    sleepMinutes: Int, sleepAtTrackEnd: Boolean, playbackSpeed: Float,
    onOpenSleepTimer: () -> Unit, onOpenSpeed: () -> Unit,
    onBack: () -> Unit, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val total = duration.coerceAtLeast(1L)
    Column(
        modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
            }
            Text("СЕЙЧАС ИГРАЕТ", modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onOpenSpeed) {
                Icon(Icons.Default.Speed, contentDescription = "Скорость воспроизведения",
                    tint = if (playbackSpeed != 1f) Color(0xFFF1F1F1) else Color.LightGray)
            }
            IconButton(onClick = onOpenSleepTimer) {
                Icon(Icons.Default.Timer, contentDescription = "Таймер сна",
                    tint = if (sleepMinutes > 0 || sleepAtTrackEnd) Color(0xFFF1F1F1) else Color.LightGray)
            }
            IconButton(onClick = onQueue) {
                Icon(Icons.Default.QueueMusic, contentDescription = "Очередь воспроизведения",
                    tint = Color(0xFFF1F1F1))
            }
        }
        Spacer(Modifier.weight(1f))
        TrackArtwork(uri = track.uri, modifier = Modifier.fillMaxWidth().aspectRatio(1f), rounded = 28.dp, placeholderSize = 112)
        Spacer(Modifier.height(34.dp))
        Text(track.title, fontSize = 24.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, color = Color.LightGray, fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        Slider(
            value = position.coerceIn(0L, total).toFloat(),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..total.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFF1F1F1), activeTrackColor = Color(0xFFF1F1F1)
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position), color = Color.LightGray, fontSize = 12.sp)
            Text(formatTime(duration), color = Color.LightGray, fontSize = 12.sp)
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Default.Shuffle, contentDescription = "Перемешать",
                    tint = if (shuffleEnabled) Color(0xFFF1F1F1) else Color.LightGray)
            }
            IconButton(onClick = onPrevious, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Предыдущий трек",
                    modifier = Modifier.size(34.dp))
            }
            FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color(0xFFF1F1F1), contentColor = Color(0xFF111111))) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Играть или пауза", modifier = Modifier.size(40.dp))
            }
            IconButton(onClick = onNext, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Default.SkipNext, contentDescription = "Следующий трек",
                    modifier = Modifier.size(34.dp))
            }
            IconButton(onClick = onRepeat) {
                Icon(
                    if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    contentDescription = when (repeatMode) {
                        Player.REPEAT_MODE_ALL -> "Повтор всего"
                        Player.REPEAT_MODE_ONE -> "Повтор трека"
                        else -> "Повтор выключен"
                    },
                    tint = if (repeatMode != Player.REPEAT_MODE_OFF) Color(0xFFF1F1F1) else Color.LightGray
                )
            }
        }
        Text(
            when (repeatMode) {
                Player.REPEAT_MODE_ALL -> "Повтор плейлиста"
                Player.REPEAT_MODE_ONE -> "Повтор текущего трека"
                else -> if (shuffleEnabled) "Случайный порядок" else "Обычный порядок"
            },
            color = Color(0xFFA5A5A5), fontSize = 11.sp
        )
        if (sleepMinutes > 0 || sleepAtTrackEnd) {
            Text(
                if (sleepAtTrackEnd) "Таймер: до конца трека" else "Таймер: $sleepMinutes мин.",
                color = Color(0xFFF1F1F1), fontSize = 12.sp
            )
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun QueueScreen(
    queue: List<Track>, currentIndex: Int,
    onBack: () -> Unit, onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Назад") }
            Column(Modifier.weight(1f)) {
                Text("Очередь", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("${queue.size} треков", color = Color(0xFFA5A5A5), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        if (queue.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Очередь пуста", color = Color(0xFFA5A5A5))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(queue, key = { index, track -> "${index}-${track.uri}" }) { index, track ->
                    Row(
                        Modifier.fillMaxWidth()
                            .background(
                                if (index == currentIndex) Color(0xFF303030) else Color(0xFF1A1A1A),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelect(index) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (index == currentIndex) "♫" else (index + 1).toString(),
                            color = Color(0xFFF1F1F1), fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(32.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(track.title, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(track.artist, color = Color(0xFFA5A5A5), fontSize = 12.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (index == currentIndex) {
                            Text("Играет", color = Color(0xFFF1F1F1), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "0:00"
    val seconds = ms / 1000
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
