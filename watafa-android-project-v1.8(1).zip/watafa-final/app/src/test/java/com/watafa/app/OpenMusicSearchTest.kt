package com.watafa.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OpenMusicSearchTest {
    @Test fun acceptsCommonAudioFormats() {
        listOf("song.mp3", "track.ogg", "audio.flac", "voice.m4a", "live.wav").forEach {
            assertTrue("Expected audio URL: $it", isAudioUrl(it))
        }
    }

    @Test fun rejectsNonAudioFiles() {
        listOf("cover.jpg", "book.pdf", "page.html", "archive.zip").forEach {
            assertFalse("Unexpected audio URL: $it", isAudioUrl(it))
        }
    }

    @Test fun acceptsExplicitCreativeCommonsAndPublicDomainLicenses() {
        assertTrue(isOpenLicense("CC BY-SA 4.0", "https://creativecommons.org/licenses/by-sa/4.0/"))
        assertTrue(isOpenLicense("CC0", "https://creativecommons.org/publicdomain/zero/1.0/"))
        assertTrue(isOpenLicense("Public Domain", ""))
    }

    @Test fun rejectsMissingOrProprietaryLicenses() {
        assertFalse(isOpenLicense("All rights reserved", ""))
        assertFalse(isOpenLicense("", ""))
    }
}
